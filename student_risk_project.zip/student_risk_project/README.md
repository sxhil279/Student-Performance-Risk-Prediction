# CSE274: Student Performance Risk Prediction
**Applied Machine Learning Project | Session 2025-26**

## Features
- 🔴 Predicts whether a student is **At Risk** of poor performance
- 📊 Shows **Risk Probability** with a visual gauge
- 📚 Recommends **weekly study hours** to achieve safe scores
- 💡 Gives **personalised action tips** based on student profile

## ML Techniques Used (mapped to syllabus)
| Syllabus Unit | Technique Used |
|---|---|
| Unit I — Data Pre-processing | Missing value imputation, categorical encoding |
| Unit II — Feature Engineering | Label encoding, aggregate feature (study_efficiency) |
| Unit V — Ensemble Learning | Random Forest Classifier (200 trees, depth=10) |
| Unit IV — Regression | Gradient Boosting Regressor for hours recommendation |
| Unit III — Evaluation | Confusion matrix, ROC-AUC, Precision-Recall curve |
| Unit V — Hyperparameter | Cross-validation (5-fold StratifiedKFold) |

## Project Structure
```
student_risk_project/
├── train_model.py        ← Run first to train & save models
├── app.py                ← Flask API backend
├── requirements.txt
├── cse274_dataset.xlsx   ← Dataset (copy here)
├── clf_model.pkl         ← Generated after training
├── reg_model.pkl         ← Generated after training
├── encoders.json         ← Generated after training
├── feature_cols.json     ← Generated after training
├── model_evaluation.png  ← Generated after training
└── frontend/
    └── index.html        ← Open this in VS Code Live Server
```

## Setup & Run

### Step 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Copy dataset
Copy `cse274_dataset.xlsx` into this folder.

### Step 3 — Train the models
```bash
python train_model.py
```
This will print accuracy metrics and save `clf_model.pkl`, `reg_model.pkl`.

### Step 4 — Start Flask API
```bash
python app.py
```
Server starts at **http://localhost:5000**

### Step 5 — Open Frontend in VS Code
- Install **Live Server** extension in VS Code
- Right-click `frontend/index.html` → **Open with Live Server**
- OR just open `http://localhost:5000` in your browser directly

## Model Performance
- Risk Classifier Accuracy: **~90%**
- ROC-AUC: **~0.95**
- Study Hours Regressor R²: **~0.99**
